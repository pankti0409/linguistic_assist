'use client'

import { useEffect, useMemo, useState } from 'react'
import {
  Activity,
  AlertTriangle,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  FileText,
  Hand,
  HeartHandshake,
  History,
  Info,
  Languages,
  Mic,
  MoreHorizontal,
  PanelRight,
  Play,
  RotateCcw,
  Settings,
  ShieldCheck,
  Sparkles,
  Square,
  ThumbsDown,
  ThumbsUp,
  UserRound,
  Volume2,
  Waves,
  Wifi,
  X,
} from 'lucide-react'

type Screen = 'patient' | 'partner' | 'setup' | 'words' | 'gestures' | 'insights'
type TurnState = 'IDLE' | 'CAPTURING' | 'FUSING' | 'AWAITING_CONFIRM' | 'SPEAKING'
type Fragment = { text: string; source: 'speech' | 'gesture' | 'lip'; gap?: string; flag?: string }
type Candidate = { text: string; added: string[] }

const candidates: Candidate[] = [
  { text: 'I would like cold water, please.', added: ['I would like', 'please'] },
  { text: 'Could I have cold water?', added: ['Could I have'] },
  { text: 'I want cold water.', added: ['I want'] },
]

const navItems: { id: Screen; label: string; icon: typeof Activity }[] = [
  { id: 'patient', label: 'My message', icon: HeartHandshake },
  { id: 'partner', label: 'Partner', icon: UserRound },
  { id: 'setup', label: 'Setup & consent', icon: ShieldCheck },
  { id: 'words', label: 'My words', icon: FileText },
  { id: 'gestures', label: 'Gestures', icon: Hand },
  { id: 'insights', label: 'Insights', icon: Activity },
]

function StatusDot({ tone = 'sage' }: { tone?: 'sage' | 'butter' | 'blush' }) {
  return <span aria-hidden="true" className={`status-dot status-dot-${tone}`} />
}

function TurnStatePill({ state }: { state: TurnState }) {
  const tone = state === 'CAPTURING' ? 'butter' : state === 'SPEAKING' ? 'sage' : state === 'AWAITING_CONFIRM' ? 'lavender' : 'sand'
  return <div className={`state-pill ${tone === 'sand' ? 'state-pill-neutral' : `state-pill-${tone}`}`}><StatusDot tone={tone === 'butter' ? 'butter' : tone === 'sage' ? 'sage' : 'blush'} /><span>{state.replace('_', ' ')}</span></div>
}

function Button({ children, variant = 'secondary', onClick, disabled, className = '', type = 'button' }: { children: React.ReactNode; variant?: 'primary' | 'secondary' | 'danger' | 'small'; onClick?: () => void; disabled?: boolean; className?: string; type?: 'button' | 'submit' }) {
  return <button type={type} disabled={disabled} onClick={onClick} className={`app-button button-${variant} ${className}`}>{children}</button>
}

function FragmentStrip({ fragments }: { fragments: Fragment[] }) {
  return <section className="paper-card fragments-card" aria-labelledby="fragments-title">
    <div className="section-heading"><div><span className="eyebrow">Live input</span><h2 id="fragments-title">What I heard</h2></div><span className="quiet-label">Long pauses are okay</span></div>
    <div className="fragment-strip" aria-live="polite">
      {fragments.length === 0 ? <p className="empty-line">Your words will appear here, one piece at a time.</p> : fragments.map((fragment, index) => <div className="fragment-wrap" key={`${fragment.text}-${index}`}>
        {index > 0 && <span className="pause-line"><span aria-hidden="true" />pause {fragment.gap}</span>}
        <div className={`fragment-chip source-${fragment.source} ${fragment.flag === 'stutter_prefix' ? 'is-faded' : ''} ${fragment.source === 'lip' ? 'is-weak' : ''}`}>
          <span className="source-tab" aria-hidden="true">{fragment.source === 'speech' ? <Mic size={16} /> : fragment.source === 'gesture' ? <Hand size={16} /> : <Waves size={16} />}</span>
          <span>{fragment.text}</span>
          {fragment.source === 'lip' && <small>weak hint</small>}
        </div>
      </div>)}
    </div>
    <div className="cleaned-row"><span className="eyebrow">Cleaned</span><span>{fragments.length ? 'water cold' : 'Nothing ready yet'}</span></div>
  </section>
}

function CandidateCard({ candidate, index, onConfirm }: { candidate: Candidate; index: number; onConfirm: (index: number, text?: string) => void }) {
  const [editing, setEditing] = useState(false)
  const [text, setText] = useState(candidate.text)
  return <article className={`candidate-card ${index === 0 ? 'candidate-best' : ''}`}>
    <div className="candidate-top"><span className="candidate-label">{index === 0 ? 'Best match' : `Option ${index + 1}`}</span><span className="candidate-check"><Check size={14} /> covers fragments</span></div>
    {editing ? <textarea aria-label="Edit candidate" value={text} onChange={(event) => setText(event.target.value)} className="candidate-editor" autoFocus /> : <p className="candidate-text">{candidate.text}</p>}
    <div className="added-words"><span className="eyebrow">Added for grammar</span><div>{candidate.added.map((word) => <span className="added-chip" key={word}>{word}</span>)}</div></div>
    <div className="candidate-actions">{editing ? <><Button variant="primary" onClick={() => onConfirm(index, text)}><Volume2 size={18} /> Say edited text</Button><Button onClick={() => setEditing(false)}>Cancel</Button></> : <><Button variant="primary" onClick={() => onConfirm(index)}><Volume2 size={18} /> Say this</Button><Button onClick={() => setEditing(true)}>Edit</Button></>}</div>
  </article>
}

function AvatarPanel({ speaking, onStart }: { speaking: boolean; onStart: () => void }) {
  return <section className="paper-card avatar-card" aria-labelledby="avatar-title">
    <div className="section-heading"><div><span className="eyebrow">Receive-only</span><h2 id="avatar-title">AI avatar</h2></div><span className="synthetic-badge"><span className="avatar-dot" /> synthetic</span></div>
    <div className="avatar-stage"><div className="avatar-face" aria-hidden="true"><div className="avatar-eye avatar-eye-left" /><div className="avatar-eye avatar-eye-right" /><div className="avatar-mouth" /></div><p>{speaking ? 'Speaking your confirmed words…' : 'Your avatar waits here.'}</p></div>
    <div className="avatar-foot"><span className="quiet-label">Camera and mic are off</span><Button variant="small" onClick={onStart}><Play size={15} /> Start avatar</Button></div>
  </section>
}

function GesturesCard() {
  return <section className="paper-card side-card"><div className="section-heading"><div><span className="eyebrow">Quick reference</span><h2>Gestures</h2></div><Hand size={21} /></div><div className="gesture-list"><div><span className="gesture-sign">Thumbs up</span><span>Yes</span></div><div><span className="gesture-sign">Thumbs down</span><span>No</span></div><div><span className="gesture-sign">Open hand</span><span>Wait</span></div></div><p className="quiet-note">Commit and clear are reserved for the backend.</p></section>
}

function PatientScreen() {
  const [state, setState] = useState<TurnState>('IDLE')
  const [fragments, setFragments] = useState<Fragment[]>([])
  const [confirmed, setConfirmed] = useState('')
  const [avatarSpeaking, setAvatarSpeaking] = useState(false)
  const [showClarify, setShowClarify] = useState(false)
  const [partial, setPartial] = useState('')

  const startTurn = () => {
    if (state !== 'IDLE') return
    setState('CAPTURING'); setConfirmed(''); setPartial('wa…')
    setFragments([{ text: 'wa', source: 'speech', gap: '—', flag: 'stutter_prefix' }])
    window.setTimeout(() => { setFragments((current) => [...current, { text: 'water', source: 'speech', gap: '1.8 s' }]); setPartial('water…') }, 750)
    window.setTimeout(() => { setFragments((current) => [...current, { text: 'cold', source: 'gesture', gap: '4.1 s' }]); setPartial('') }, 1500)
  }
  const endTurn = () => { setState('FUSING'); window.setTimeout(() => setState('AWAITING_CONFIRM'), 650) }
  const confirm = (_index: number, text?: string) => { setConfirmed(text || candidates[_index].text); setState('SPEAKING'); setAvatarSpeaking(true); window.setTimeout(() => { setAvatarSpeaking(false); setState('IDLE') }, 2800) }
  const reject = () => { setFragments([]); setPartial(''); setState('IDLE') }

  return <div className="patient-layout">
    <main className="patient-main">
      <section className="paper-card partner-context"><div className="context-icon"><HeartHandshake size={22} /></div><div><span className="eyebrow">Partner said</span><p>“Water or tea?”</p></div><span className="context-tag">context</span></section>
      <FragmentStrip fragments={fragments} />
      <section className="capture-zone"><div className="capture-copy"><div className="partial-line">{partial ? <><Mic size={18} /> <em>{partial}</em></> : <span>Take your time. Long pauses are fine.</span>}</div><div className="silence-meter"><span className="meter-ring" /><span>draft silence is informational only</span></div></div><Button variant="primary" className="start-button" onClick={state === 'CAPTURING' ? endTurn : startTurn} disabled={state === 'FUSING' || state === 'AWAITING_CONFIRM' || state === 'SPEAKING'}>{state === 'CAPTURING' ? <><Square size={20} fill="currentColor" /> I&apos;m done</> : state === 'FUSING' ? <><Waves size={20} /> Finding your words…</> : state === 'SPEAKING' ? <><Volume2 size={20} /> Speaking…</> : <><Mic size={22} /> Start my message</>}</Button></section>
      {state === 'AWAITING_CONFIRM' && <section className="candidates-section"><div className="candidate-heading"><div><span className="eyebrow">Nothing is spoken yet</span><h2>Choose what you meant</h2></div><Button variant="danger" onClick={reject}><X size={18} /> None of these</Button></div><div className="candidate-list">{candidates.map((candidate, index) => <CandidateCard key={candidate.text} candidate={candidate} index={index} onConfirm={confirm} />)}</div><p className="privacy-line"><ShieldCheck size={16} /> Video, mouth clips and audio stay in memory only and are never saved.</p></section>}
      {confirmed && <div className="confirmed-note"><Check size={18} /><span>Confirmed: <strong>{confirmed}</strong></span></div>}
      {showClarify && <section className="paper-card clarify-card"><div><span className="eyebrow">Question 1 of 2</span><h2>Do you mean you are in pain?</h2><p>Answer with a button or a thumbs up / down gesture.</p></div><div className="clarify-actions"><Button variant="primary" onClick={() => setShowClarify(false)}><ThumbsUp size={22} /> YES</Button><Button variant="danger" onClick={() => setShowClarify(false)}><ThumbsDown size={22} /> NO</Button></div></section>}
    </main>
    <aside className="patient-side"><TurnStatePill state={state} /><AvatarPanel speaking={avatarSpeaking} onStart={() => setAvatarSpeaking(true)} /><GesturesCard /><button className="scenario-button" onClick={() => setShowClarify(true)}><CircleHelp size={17} /> Try clarification scenario <ChevronDown size={15} /></button></aside>
  </div>
}

function SimpleScreen({ screen }: { screen: Exclude<Screen, 'patient'> }) {
  const content = {
    partner: { eyebrow: 'Partner mode', title: 'Partner is speaking', copy: 'Hold the button while your partner speaks. Their words become context, not a trigger to speak.', icon: UserRound },
    setup: { eyebrow: 'Safety first', title: 'Setup & consent', copy: 'Choose what PS-16 can use. You can change these choices anytime.', icon: ShieldCheck },
    words: { eyebrow: 'Personal language', title: 'My words', copy: 'Names, places and phrases that help the scribe understand you.', icon: FileText },
    gestures: { eyebrow: 'Your lexicon', title: 'Gestures', copy: 'Review the words your stable gestures represent.', icon: Hand },
    insights: { eyebrow: 'Developer view', title: 'Insights', copy: 'Latency and evaluation data from the backend. Numbers only appear when measured.', icon: Activity },
  }[screen]
  const Icon = content.icon
  return <main className="simple-screen"><div className="simple-header"><div className="simple-icon"><Icon size={28} /></div><div><span className="eyebrow">{content.eyebrow}</span><h1>{content.title}</h1><p>{content.copy}</p></div></div><div className="simple-grid"><section className="paper-card empty-panel"><Info size={22} /><h2>This part is ready for the backend</h2><p>PS-16 keeps this screen calm until it has something real to show.</p><Button variant="secondary"><RotateCcw size={16} /> Check again</Button></section><section className="paper-card note-panel"><span className="eyebrow">Important</span><h2>Assistive proof of concept.</h2><p>Not a diagnostic tool. Not clinically validated. No audio or video is saved in this browser.</p></section></div></main>
}

export default function PS16App() {
  const [screen, setScreen] = useState<Screen>('patient')
  const [navOpen, setNavOpen] = useState(false)
  const [mockRibbon, setMockRibbon] = useState(true)
  const screenLabel = useMemo(() => navItems.find((item) => item.id === screen)?.label, [screen])
  useEffect(() => { document.documentElement.classList.add('ps16-root'); return () => document.documentElement.classList.remove('ps16-root') }, [])
  return <div className="ps16-app">
    {mockRibbon && <div className="mock-ribbon"><Sparkles size={14} /> MOCK DATA <button onClick={() => setMockRibbon(false)} aria-label="Dismiss mock data notice"><X size={14} /></button></div>}
    <header className="app-header"><button className="brand-mark" onClick={() => setScreen('patient')} aria-label="Go to My message"><span className="brand-symbol"><Waves size={24} /></span><span><strong>PS-16</strong><small>Voice Bridge</small></span></button><div className="mobile-title">{screenLabel}</div><div className="header-actions"><div className="connection"><StatusDot /> <span>Backend connected</span></div><div className="language"><Languages size={17} /><span>EN</span><ChevronDown size={14} /></div><span className="header-avatar"><span className="avatar-dot" /> AI avatar</span><button className="icon-button" aria-label="Open settings"><Settings size={20} /></button><button className="menu-toggle" onClick={() => setNavOpen(!navOpen)} aria-label="Open navigation"><PanelRight size={20} /></button></div></header>
    <div className="app-body"><nav className={`app-nav ${navOpen ? 'nav-open' : ''}`} aria-label="Main navigation"><div className="nav-intro"><span className="eyebrow">A quiet place to speak</span><p>Nothing is spoken until you say so.</p></div>{navItems.map(({ id, label, icon: Icon }) => <button key={id} className={`nav-item ${screen === id ? 'nav-item-active' : ''}`} onClick={() => { setScreen(id); setNavOpen(false) }}><Icon size={20} /><span>{label}</span>{id === 'patient' && <span className="nav-arrow">›</span>}</button>)}<div className="nav-bottom"><div className="privacy-mini"><ShieldCheck size={17} /><span>Private by design<br /><small>in-memory only</small></span></div><button className="event-log-button"><History size={17} /> Event log <MoreHorizontal size={17} /></button></div></nav><div className="content-area">{screen === 'patient' ? <PatientScreen /> : <SimpleScreen screen={screen} />}</div></div>
  </div>
}
